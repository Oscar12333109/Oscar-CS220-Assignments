function setup() {
  createCanvas(100, 100);

  describe("A vertical blue line moves left and right following the mouse's x-position.");
}

function draw() {
  background(200);

  // Make the line blue.
stroke(0, 0, 255);

  // Draw a vertical line that follows the mouse's x-coordinate.
  line(mouseX, 0, mouseX, 100);
 
textFont('Courier New');
  textSize(11);
  text('Hello There', 20, 50);

  describe('The text "Hello There" written in blue in the middle of a gray square.');
}