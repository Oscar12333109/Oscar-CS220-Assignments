function setup() {
createCanvas(100, 100);
 
describe(
'A green triangle and a face on a gray background.');

}

function draw() {
background(200);

 
// Draw a green triangle.
fill('green');
triangle(30, 10, 50, 20, 50, 40);

// Move the origin to the center.
translate(50, 50);

// Draw the face.
fill(255, 220, 180);
circle(0, 0, 60);
  
// Style the eyes.
fill('white');

 
// Draw the eyes.
ellipse(-12, -10, 12, 8);
ellipse(12, -10, 12, 8);

}

