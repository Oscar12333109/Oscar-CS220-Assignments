  

let anaglyph;
let font;

async function setup() {
    createCanvas(windowWidth, windowHeight, WEBGL);
    anaglyph = createAnaglyph(this);
    font = await loadFont("AdobeClean-Light.otf");
}

function draw() {
    anaglyph.draw(scene);
}

function scene(pg) {
    pg.background(255);
    pg.fill(60);
    pg.textFont(font, 100);
    pg.rotateY(-frameCount / 300);
    pg.text("THX", 0, 0);
}

